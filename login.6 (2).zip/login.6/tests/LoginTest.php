<?php
// Gebruik de TestCase klasse van PHPUnit
use \PHPUnit\Framework\TestCase;
//  de User klasse word gebruikt
use login_tests\classes\User;

// Filename moet gelijk zijn aan de classname LoginTest
class LoginTest extends TestCase
{
    // Variabele om een ​​User object op te slaan voor alle tests
    protected $user;

    // Initialiseer een nieuw User object voor elke test
    protected function setUp(): void
    {
        $this->user = new User;
    }

    // Test voor het instellen en ophalen van het wachtwoord
    public function testSetAndGetPassword()
    {
        $password = "welkom123";
        $this->user->SetPassword($password);
        $this->assertEquals($password, $this->user->GetPassword());
    }

    // Test of de gebruikersnaam leeg is
    public function testValidateUserWithEmptyUsername()
    {
        $this->user->SetPassword("password123");
        $errors = $this->user->ValidateUser();
        $this->assertContains("Invalid username", $errors);
    }

    // Test of het wachtwoord leeg is
    public function testValidateUserWithEmptyPassword()
    {
        $this->user->username = "gert";
        $errors = $this->user->ValidateUser();
        $this->assertContains("Invalid password", $errors);
    }

    // Test of de gebruiker niet is ingelogd als er geen sessie is ingesteld
    public function testIsLoggedin_notset(){
        $this->user->Logout();
        $this->assertFalse($this->user->IsLoggedin());
    }

    // Test of de gebruiker niet is ingelogd als een sessie is gestart maar de gebruiker niet is ingelogd
    public function testIsLoggedin_set(){
        session_start();
        $_SESSION['user'] = "test";
        $this->assertFalse($this->user->IsLoggedin());
    }

    // Test voor het uitloggen van de gebruiker
    public function testLogout()
    {
        // Start een sessie en meld de gebruiker af
        session_start();
        $this->user->Logout();
        // Controleer of de sessie is verwijderd
        $isDeleted = (session_status() == PHP_SESSION_NONE || empty(session_id()));
        $this->assertTrue($isDeleted);
    }
}

